const express=require('express');
const app=express();
const bodyParser=require('body-parser');
const cors=require('cors');
const {mongoose}=require('./db');
app.use(bodyParser.json());
app.use(cors({origin:'http://localhost:4200'}));

app.get('/',(req,res)=>{
    res.send("welcome..")
});

const userRouter=require('./routes/api');
app.use('/api',userRouter);

app.listen(8000,()=>{
    console.log("server running on port"+8000);
});