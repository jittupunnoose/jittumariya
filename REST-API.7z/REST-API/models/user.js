const mongoose=require('mongoose');
var bcrypt = require('bcryptjs');
const User=mongoose.model('User',{
    username:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    empid:{
        type:String,
        required:true
    },
    name:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    phone:{
        type:Number,
        required:true
    },
    designation:{
        type:String,
        required:true
    },
    address:{
        type:String,
        required:true
    }
});


// save user to database
User.addUser = function(user, callback){

    bcrypt.genSalt(10, (err, salt)=>{
        if(err){
            callback('server error');
        }else {
            bcrypt.hash(user.password, salt, (err, hash)=>{
                if(err){
                    callback('server error');
                }else{
                    user.password = hash;
                    user.save((err, result)=>{
                        if(err){
                            console.log(err);
                            callback('Failed to add', null);
                        } else{
                            callback(null, 'user added');
                        }
                    });
                }
            });
        }
    });    
};

// login 
User.login = function(username, password, callback){
    User.findOne({username: username}, (err, user)=>{
        if(err){
            console.log(err);
            callback('server error');
        }else if(user==undefined){
            callback('user not found');
        }else{
            bcrypt.compare(password, user.password,(err, isMatch)=>{
                if(err){
                    callback('server error');
                }else if(isMatch===true){
                    callback(null, 'login successfully');
                }else{
                    callback('login info incorrect');
                }
            });
        }
    });
}

module.exports={User};

